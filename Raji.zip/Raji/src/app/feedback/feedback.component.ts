import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { FeedbackService } from '../service/feedback.service';
import { feedbackModal } from '../model/feedbackModal';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  currentRate = '1';
  selected = 0;
  hovered = 0;
  readonly = false;
  id: number;
 @Input() newFeedback: feedbackModal;
  constructor(private feedbackservice: FeedbackService) {
    this.newFeedback = new feedbackModal();
    this.id = 1001;
  }


  ngOnInit() {
  }
  submit() {
    this.feedbackservice.add(this.newFeedback, this.id).subscribe(
      result => {
        console.log(result);
        console.log('Added Successfully');
      }, error => { console.log(error) ;
      }
    );
  }
}


